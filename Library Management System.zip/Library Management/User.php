<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<!--Once the form is submitted, all the form data is forwarded to InsertBooks.php -->
<form action="used.php" method="post">

<table border="2" align="center" cellpadding="5" cellspacing="5">
<tr>
<td> Enter user id :</td>
<td> <input type="text" name="user_id" size="48"> </td>
</tr>
<tr>
<td> Enter name :</td>
<td> <input type="text" name="name" size="48"> </td>
</tr>
<tr>
<td> Enter city :</td>
<td> <input type="text" name="city" size="48"> </td>
</tr>
<tr>
<td> Enter street :</td>
<td> <input type="text" name="street" size="48"> </td>
</tr>
<tr>
<td></td>
<td>
<input type="submit" value="submit">
<input type="reset" value="Reset">
</td>
</tr>
</table>
</form>
<br>
<a href="SeeBorrowed.php"> To see the list of books issued click here </a>
<br>
<a href="SeeUser.php"> To see the list of user added click here </a>
<br>
<a href="Borrow.php"> To issue book to user click here </a>
<br>
<a href="Deletebor.php"> To delete issued book click here </a>
</body>
</html>