
<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<!--Once the form is submitted, all the form data is forwarded to InsertBooks.php -->
<form action="lib.php" method="post">

<table border="2" align="center" cellpadding="5" cellspacing="5">
<tr>
<td> Enter id :</td>
<td> <input type="text" name="id" size="48"> </td>
</tr>
<tr>
<td> Enter name :</td>
<td> <input type="text" name="name" size="48"> </td>
</tr>
<tr>
<td> Enter city :</td>
<td> <input type="text" name="city" size="48"> </td>
</tr>
<tr>
<td> Enter street :</td>
<td> <input type="text" name="street" size="48"> </td>
</tr>
<tr>
<td></td>
<td>
<input type="submit" value="submit">
<input type="reset" value="Reset">
</td>
</tr>
</table>
</form>
<br>
<a href="Managebook.php"> To manage books click here </a>
<br>
<a href="SeeBook.php"> To see books managed click here </a>
</body>
</html>