<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<br>

<?php
include("DBConnection.php");

$delebor = $_REQUEST["delebor"];

$query = "delete from borrowed where isbn like '%$delebor%'"; //delete with a book name in the table book_info
$result = mysqli_query($db,$query);

if(mysqli_num_rows($result)==0)if(mysqli_num_rows($result)==0)

{echo"<center>book deleted in the library by the isbn $delebor </center>" ;}
else{
echo"<center>book not deleted </center>";}
?>
<br>
<a href="SeeBorrowed.php"> To see issued book list </a>
<br>
<a href="Index.php"> To go back to main page click here </a>


</body>
</html>