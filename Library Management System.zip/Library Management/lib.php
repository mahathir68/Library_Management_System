<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<br>

<?php
include("DBConnection.php");

$id=$_POST["id"];
$name=$_POST["name"];
$city=$_POST["city"];
$street=$_POST["street"];


$query = "insert into librarian(id,name,city,street) values('$id','$name','$city','$street')"; //Insert query to add librarian details into the book_info table
$result = mysqli_query($db,$query);

?>

<h3> Librarian information has been inserted successfully </h3>


</body>
</html>