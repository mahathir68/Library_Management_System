<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<br>

<?php
include("DBConnection.php");

$query = "select isbn,title,author,edition,publication,id,dateadded from managed"; //search with a book name in the table book_info
$result = mysqli_query($db,$query);

if(mysqli_num_rows($result)>0)if(mysqli_num_rows($result)>0)

{
?>

<table border="2" align="center" cellpadding="5" cellspacing="5">

<tr>
<th> ISBN </th>
<th> Title </th>
<th> Author </th>
<th> Edition </th>
<th> Publication </th>
<th> id </th>
<th> dateadded</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result))
{
?>
<tr>
<td><?php echo $row["isbn"];?> </td>
<td><?php echo $row["title"];?> </td>
<td><?php echo $row["author"];?> </td>
<td><?php echo $row["edition"];?> </td>
<td><?php echo $row["publication"];?> </td>
<td><?php echo $row["id"];?> </td>
<td><?php echo $row["dateadded"];?> </td>
</tr>
<?php
}?>
</table>
<?php
}
else if(mysqli_num_rows($result)==0){
echo "<center>No books found in the library by the name $search </center>";}
?>
<br>
<a href="Index.php"> To go back to main page click here </a>
</body>
</html>
<br>