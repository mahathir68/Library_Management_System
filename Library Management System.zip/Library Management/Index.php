<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h1>Simple Library Management System</h1></center>
<a href="EnterBooks.php"><center> To enter a new Book information click here </center></a>
<br>
<a href="SearchBooks.php"><center> To search for the Book information click here </center> </a>
<br>
<a href="DeleteBook.php"><center> To delete a Book information click here </center> </a>
<br>
<a href="Updatebook.php"><center>To update a Book information click here</center></a>
<br>
<a href="Librarian.php"><center>To go to Librarian page click here</center></a>
<br>
<a href="User.php"><center>To go to user page click here</center></a>
<br>
<a href="ShowAll.php"><center>To see all books</center></a>
<br>
	
</br>
<center><img src="Bibliothèque_de_l'Assemblée_Nationale_(Lunon).jpg" alt="alternatetext" style="width:450px;height:400px;"></center>


</body>
</html>
