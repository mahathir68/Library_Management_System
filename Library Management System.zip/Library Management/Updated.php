<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<br>

<?php
include("DBConnection.php");

$updat = $_REQUEST["updat"];
$new=$_POST["new"];


$query = "update book_info set title='$new' where isbn like '%$updat%'"; 
$result = mysqli_query($db,$query);

?>

<br>
<a href="ShowAll.php"> To see all books click here </a>
</body>
</html>
<br>