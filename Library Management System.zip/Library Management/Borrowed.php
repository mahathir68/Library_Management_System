<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<br>

<?php
include("DBConnection.php");

$isbn=$_POST["isbn"];
$user_id=$_POST["user_id"];
$dateissued=$_POST["dateissued"];



$query = "insert into borrowed(isbn,user_id,dateissued) values('$isbn','$user_id','$dateissued')"; //Insert query to add book details into the managed table
$result = mysqli_query($db,$query);

?>

<h3> Book information is inserted successfully </h3>

<a href="SeeBorrowed.php"> To see the list of book issued click here </a>

</body>
</html>