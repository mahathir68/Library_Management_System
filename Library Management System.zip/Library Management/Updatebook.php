<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<form action = "Updated.php" method="post">
<br>
<center>Enter the isbn of the book to be updated :
<input type="text" name="updat" size="48"> </center>
<br>
<center>Enter the new title:
<input type="text" name="new" size="48"></center>
<br></br>
<center>
<input type="submit" value="submit">
<input type="reset" value="Reset">
</center>
<br>
</form>
</body>
</html>