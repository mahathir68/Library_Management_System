<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<br>

<?php
include("DBConnection.php");

$user_id=$_POST["user_id"];
$name=$_POST["name"];
$city=$_POST["city"];
$street=$_POST["street"];


$query = "insert into user(user_id,name,city,street) values('$user_id','$name','$city','$street')"; //Insert query to add librarian details into the book_info table
$result = mysqli_query($db,$query);

?>

<h3> User information has been inserted successfully </h3>
<a href="SeeUser.php"> To see the list of users added click here </a>

</body>
</html>