<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<br>

<?php
include("DBConnection.php");

$delete = $_REQUEST["delete"];

$query = "delete from book_info where isbn like '%$delete%'"; //delete with a book name in the table book_info
$result = mysqli_query($db,$query);

if(mysqli_num_rows($result)==0)if(mysqli_num_rows($result)==0)

{echo"<center>book deleted in the library by the isbn $delete </center>" ;}
else{
echo"<center>book not deleted </center>";}
?>

<br>
<a href="ShowAll.php"> To see all books click here </a>
</body>
</html>