<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<form action = "Delbor.php" method="post">
<br>
<center>Enter the isbn of the book to be deleted :
<input type="text" name="delebor" size="48">
<br></br>
<input type="submit" value="submit">
<input type="reset" value="Reset">
</center>
<br>
</form>
</body>
</html>