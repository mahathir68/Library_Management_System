<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<br>

<?php
include("DBConnection.php");

$query = "select user_id,name,city,street from user"; //search with a book name in the table book_info
$result = mysqli_query($db,$query);

if(mysqli_num_rows($result)>0)if(mysqli_num_rows($result)>0)

{
?>

<table border="2" align="center" cellpadding="5" cellspacing="5">

<tr>
<th> user_id </th>
<th> name </th>
<th> city </th>
<th> street </th>
</tr>

<?php while($row = mysqli_fetch_assoc($result))
{
?>
<tr>
<td><?php echo $row["user_id"];?> </td>
<td><?php echo $row["name"];?> </td>
<td><?php echo $row["city"];?> </td>
<td><?php echo $row["street"];?> </td>
</tr>
<?php
}?>
</table>
<?php
}
else if(mysqli_num_rows($result)==0){
echo "<center>No books found in the library by the name $search </center>";}
?>
<br>
<a href="User.php"> To go back to user page click here </a>
</body>
</html>
<br>