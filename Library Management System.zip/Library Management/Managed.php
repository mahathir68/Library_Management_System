<!DOCTYPE HTML>
<html>
<body bgcolor="87ceeb">
<center><h2>Simple Library Management System</h2></center>
<br>

<?php
include("DBConnection.php");

$isbn=$_POST["isbn"];
$title=$_POST["title"];
$author=$_POST["author"];
$edition=$_POST["edition"];
$publication=$_POST["publication"];
$id=$_POST["id"];
$dateadded=$_POST["dateadded"];


$query = "insert into managed(isbn,title,author,edition,publication,id,dateadded) values('$isbn','$title','$author','$edition','$publication','$id','$dateadded')"; //Insert query to add book details into the managed table
$result = mysqli_query($db,$query);

?>

<h3> Book information is inserted successfully </h3>

<a href="SeeBook.php"> To see the list of book added click here </a>

</body>
</html>